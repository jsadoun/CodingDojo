public class FizzBuzzTest {
    public static void main(String [] args) {
        Fizzbuzz ofNew = new Fizzbuzz();
        String result = ofNew.fizzBuzz(15);
        System.out.println(result);
    }
}