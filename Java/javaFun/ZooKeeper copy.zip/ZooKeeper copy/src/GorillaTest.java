
public class GorillaTest {
	public static void main(String[] args) {
		Gorilla g1 = new Gorilla();
		
		g1.throwSomething();
		g1.throwSomething();
		g1.throwSomething();
		g1.displayEnergy();
		System.out.println("******");
		g1.eatBananas();
		g1.eatBananas();
		g1.eatBananas();
		g1.displayEnergy();
		System.out.println("******");
		g1.climb();
		g1.displayEnergy();
	}
}




//throw three things, eat bananas twice, and climb once.