package com.sadounj.prodsandcats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdsandcatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdsandcatsApplication.class, args);
	}
}
