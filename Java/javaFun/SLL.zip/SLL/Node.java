public class Node{
    public int value;
    public Node next = null;

    public Node(int number){
        this.value = number;
    }   

}
