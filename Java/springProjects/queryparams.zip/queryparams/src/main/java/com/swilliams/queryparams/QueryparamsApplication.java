package com.swilliams.queryparams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryparamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryparamsApplication.class, args);
	}
}
